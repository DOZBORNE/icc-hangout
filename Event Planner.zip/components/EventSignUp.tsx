"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { signUpForEvent, removeFromEvent, getUserProfile } from "@/app/actions"
import { useAuth } from "@/components/AuthProvider"
import { useEvents } from "@/contexts/EventContext"
import { toast } from "@/components/ui/use-toast"
import { Check, X } from "lucide-react"
import { isValid } from "date-fns"

type EventSignUpProps = {
  eventId: string
  eventDate: string
  attendees: Array<{ user_id: string; attendee_name: string }>
}

export default function EventSignUp({ eventId, eventDate, attendees }: EventSignUpProps) {
  const { user } = useAuth()
  const { updateEvent, refreshEvents } = useEvents()
  const [isAttending, setIsAttending] = useState(false)
  const [isPastEvent, setIsPastEvent] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (user) {
      setIsAttending(attendees?.some((attendee) => attendee.user_id === user.id))
    }
    const date = new Date(eventDate)
    setIsPastEvent(isValid(date) && date < new Date())
  }, [attendees, user, eventDate])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (user && !isPastEvent) {
      setIsLoading(true)
      try {
        const userProfile = await getUserProfile(user.id)
        const attendeeName = userProfile.full_name || user.email
        if (isAttending) {
          await removeFromEvent(eventId, user.id)
          updateEvent({
            id: eventId,
            attendees: attendees.filter((a) => a.user_id !== user.id),
          } as any)
          toast({
            title: "Success",
            description: "You have been removed from the event.",
          })
        } else {
          await signUpForEvent(eventId, user.id, attendeeName)
          updateEvent({
            id: eventId,
            attendees: [...attendees, { user_id: user.id, attendee_name: attendeeName }],
          } as any)
          toast({
            title: "Success",
            description: "You have signed up for the event.",
          })
        }
        setIsAttending(!isAttending)
        await refreshEvents()
      } catch (error) {
        console.error("Error updating event attendance:", error)
        toast({
          title: "Error",
          description: "Failed to update event attendance. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }
  }

  if (!user) {
    return null
  }

  return (
    <form onSubmit={handleSubmit} className="flex-shrink-0">
      <Button
        type="submit"
        className={
          isAttending
            ? "w-full sm:w-auto bg-red-100 text-red-600 hover:bg-red-200 hover:text-red-700 border border-red-200"
            : "w-full sm:w-auto bg-primary-500 hover:bg-primary-600 text-white"
        }
        disabled={isPastEvent || isLoading}
      >
        {isPastEvent ? (
          "Event has passed"
        ) : isLoading ? (
          "Updating..."
        ) : isAttending ? (
          <span className="flex items-center justify-center gap-2">
            <X className="h-4 w-4" />
            Cancel Attendance
          </span>
        ) : (
          <span className="flex items-center justify-center gap-2">
            <Check className="h-4 w-4" />
            Attend Event
          </span>
        )}
      </Button>
    </form>
  )
}

