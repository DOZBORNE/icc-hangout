"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, Clock, MapPin, Users } from "lucide-react"
import Image from "next/image"
import AttendeesList from "@/components/AttendeesList"
import EventSignUp from "@/components/EventSignUp"
import { useAuth } from "@/components/AuthProvider"
import Link from "next/link"
import { format } from "date-fns"
import type { Event } from "@/types"
import { uploadEventImage, addComment, getComments, getUserProfile } from "@/app/actions"
import CommentList from "./CommentList"
import { toast } from "@/components/ui/use-toast"

export default function EventDetails({ event }: { event: Event }) {
  const [imageUrl, setImageUrl] = useState<string | null>(event.image_url || null)
  const [comment, setComment] = useState("")
  const [comments, setComments] = useState<any[]>([])
  const { user } = useAuth()

  useEffect(() => {
    const fetchComments = async () => {
      try {
        const fetchedComments = await getComments(event.id)
        setComments(fetchedComments)
      } catch (error) {
        console.error("Error fetching comments:", error)
        toast({
          title: "Error",
          description: "Failed to load comments. Please try again later.",
          variant: "destructive",
        })
      }
    }

    fetchComments()
  }, [event.id])

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && user && user.id === event.creator_id) {
      const formData = new FormData()
      formData.append("image", file)
      const uploadedImageUrl = await uploadEventImage(event.id, formData)
      if (uploadedImageUrl) {
        setImageUrl(uploadedImageUrl)
      }
    }
  }

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (user && comment.trim()) {
      try {
        await addComment(event.id, user.id, comment)
        const userProfile = await getUserProfile(user.id)
        const newComment = {
          id: Date.now().toString(),
          content: comment,
          created_at: new Date().toISOString(),
          user: {
            id: user.id,
            email: user.email,
            full_name: userProfile.full_name,
            avatar_url: userProfile.avatar_url,
          },
        }
        setComments((prevComments) => [newComment, ...prevComments])
        setComment("")
        toast({
          title: "Success",
          description: "Your comment has been added.",
        })
      } catch (error) {
        console.error("Error adding comment:", error)
        toast({
          title: "Error",
          description: "Failed to add comment. Please try again.",
          variant: "destructive",
        })
      }
    }
  }

  const eventDate = new Date(event.date)

  return (
    <div className="bg-white rounded-lg shadow-sm border border-secondary-200 p-6">
      <h1 className="text-3xl font-bold mb-6 text-primary-800">{event.title}</h1>

      <div className="mb-6">
        <div className="relative h-64 md:h-96 rounded-lg overflow-hidden">
          <Image
            src={
              imageUrl ||
              "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/placeholder-x1NcEGbbJMI48lgVdfKLf0L0h5LYbX.png" ||
              "/placeholder.svg" ||
              "/placeholder.svg"
            }
            alt={event.title}
            layout="fill"
            objectFit="cover"
          />
          {user && user.id === event.creator_id && (
            <div className="absolute bottom-4 right-4">
              <Input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="image-upload" />
              <label
                htmlFor="image-upload"
                className="cursor-pointer inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
              >
                Change Image
              </label>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center text-primary-600">
            <Calendar className="h-5 w-5 mr-2" />
            <span>{format(eventDate, "EEEE, MMMM do, yyyy")}</span>
          </div>
          <div className="flex items-center text-primary-600">
            <Clock className="h-5 w-5 mr-2" />
            <span>{format(eventDate, "h:mm a")}</span>
          </div>
          <div className="flex items-center text-primary-600">
            <MapPin className="h-5 w-5 mr-2" />
            <span>{event.location || "Location TBA"}</span>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-2 text-primary-800">Description</h2>
          <p className="text-primary-600">{event.description}</p>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4 text-primary-800">Attendees</h2>
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-start">
          <AttendeesList attendees={event.attendees.map((a) => a.attendee_name)} eventName={event.title} />
          <div className="flex-shrink-0">
            {user ? (
              <EventSignUp eventId={event.id} eventDate={event.date} attendees={event.attendees} />
            ) : (
              <Link href="/login">
                <Button className="w-full sm:w-auto bg-secondary-500 hover:bg-secondary-600 text-white">
                  Sign in to attend event
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4 text-primary-800">Comments</h2>
        {user ? (
          <form onSubmit={handleCommentSubmit} className="space-y-4">
            <Textarea
              placeholder="Leave a comment..."
              className="mb-4 border-secondary-200"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              aria-label="Comment"
            />
            <Button type="submit" className="bg-primary-500 hover:bg-primary-600 text-white">
              Post Comment
            </Button>
          </form>
        ) : (
          <p className="text-primary-600">Please sign in to leave a comment.</p>
        )}
        <CommentList comments={comments} />
      </div>
    </div>
  )
}

