"use client"

import { useEffect, useState } from "react"
import EventSignUp from "./EventSignUp"
import AttendeesList from "./AttendeesList"
import type { Event } from "@/types"
import { useAuth } from "@/components/AuthProvider"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useEvents } from "@/contexts/EventContext"
import { format } from "date-fns"
import { Calendar, Clock } from "lucide-react"

export default function UpcomingEvent() {
  const { events } = useEvents()
  const [upcomingEvent, setUpcomingEvent] = useState<Event | null>(null)
  const { user } = useAuth()

  useEffect(() => {
    const now = new Date()
    const nextEvent =
      events
        .filter((event) => new Date(event.date) > now)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0] || null
    setUpcomingEvent(nextEvent)
  }, [events])

  if (!upcomingEvent) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-secondary-200 p-6">
        <h2 className="text-xl font-semibold text-primary-800 mb-4">Next Upcoming Event</h2>
        <p className="text-primary-600">No upcoming events yet</p>
      </div>
    )
  }

  const eventDate = new Date(upcomingEvent.date)

  return (
    <div className="bg-white rounded-lg shadow-sm border border-secondary-200 p-6">
      <h2 className="text-xl font-semibold text-primary-800 mb-6">Next Upcoming Event</h2>
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-primary-800">{upcomingEvent.title}</h3>
          <p className="mt-2 text-primary-600">{upcomingEvent.description}</p>
        </div>

        <div className="flex flex-col space-y-2">
          <div className="flex items-center text-primary-600">
            <Calendar className="h-4 w-4 mr-2" />
            <span>{format(eventDate, "EEEE, MMMM do, yyyy")}</span>
          </div>
          <div className="flex items-center text-primary-600">
            <Clock className="h-4 w-4 mr-2" />
            <span>{format(eventDate, "h:mm a")}</span>
          </div>
        </div>

        <div className="border-t border-secondary-200 pt-4">
          <p className="text-sm text-primary-500 mb-2">{upcomingEvent.attendees?.length || 0} people attending</p>
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-start mt-4">
            <AttendeesList
              attendees={upcomingEvent.attendees?.map((a) => a.attendee_name) || []}
              eventName={upcomingEvent.title}
            />
            <div className="flex-shrink-0">
              {user ? (
                <EventSignUp
                  eventId={upcomingEvent.id}
                  eventDate={upcomingEvent.date}
                  attendees={upcomingEvent.attendees}
                />
              ) : (
                <Link href="/login">
                  <Button className="w-full sm:w-auto bg-secondary-500 hover:bg-secondary-600 text-white">
                    Sign in to attend event
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

