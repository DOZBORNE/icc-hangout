"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Users } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

interface AttendeesListProps {
  attendees: string[]
  eventName: string
}

export default function AttendeesList({ attendees, eventName }: AttendeesListProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="flex items-center gap-2 text-primary-600 border-secondary-200 hover:bg-secondary-50"
        >
          <Users className="h-4 w-4" />
          <span>View attendees</span>
          <span className="ml-auto text-primary-400">{attendees.length}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Attendees for {eventName}</DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          {attendees.length > 0 ? (
            <ul className="space-y-2">
              {attendees.map((attendee, index) => (
                <li key={index} className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-secondary-200 flex items-center justify-center">
                    <span className="text-sm font-medium text-primary-600">{attendee.charAt(0).toUpperCase()}</span>
                  </div>
                  <span className="text-primary-600">{attendee}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-primary-500">No attendees yet</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

