"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { createEvent } from "@/app/actions"

export default function EventScheduler() {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await createEvent({ title, description, date, time })
    setTitle("")
    setDescription("")
    setDate("")
    setTime("")
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-xl font-semibold">Schedule an Event</h2>
      <Input
        type="text"
        placeholder="Event Title (e.g., 'Quarterly Review Meeting')"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <Textarea
        placeholder="Event Description (e.g., 'Quarterly meeting to review our progress and set goals for the next quarter')"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        required
      />
      <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} required placeholder="Event Date" />
      <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} required placeholder="Event Time" />
      <Button type="submit">Schedule Event</Button>
    </form>
  )
}

