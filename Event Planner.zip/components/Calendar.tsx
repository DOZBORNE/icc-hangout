import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { useState } from "react"
import { getEvents } from "@/app/actions"
import EventList from "./EventList"

export default function Calendar() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [events, setEvents] = useState([])

  const handleSelect = async (selectedDate: Date | undefined) => {
    setDate(selectedDate)
    if (selectedDate) {
      const fetchedEvents = await getEvents(selectedDate)
      setEvents(fetchedEvents)
    }
  }

  return (
    <div>
      <CalendarComponent mode="single" selected={date} onSelect={handleSelect} className="rounded-md border" />
      <EventList events={events} />
    </div>
  )
}

