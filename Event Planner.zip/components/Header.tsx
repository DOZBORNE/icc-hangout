"use client"
import Link from "next/link"
import { useAuth } from "./AuthProvider"
import { Button } from "./ui/button"
import { useState } from "react"
import { Menu, User } from "lucide-react"
import Image from "next/image"

export default function Header() {
  const { user, signOut } = useAuth()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const getFirstName = (name: string) => {
    return name.split(" ")[0]
  }

  const displayName = user ? getFirstName(user.user_metadata.full_name || user.email || "") : ""

  return (
    <header className="bg-white border-b border-secondary-200">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/icc-hangout-tdbaqOT3VuQXHklM6e6J1TQywHfKfN.svg"
              alt="ICC Hangout"
              width={120}
              height={26}
              className="h-8 w-auto"
            />
          </Link>

          <button
            className="md:hidden text-primary-600 hover:text-primary-800"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="h-6 w-6" />
          </button>

          <nav
            className={`${
              isMenuOpen ? "absolute left-0 right-0 top-16 bg-white border-b border-secondary-200 shadow-lg" : "hidden"
            } md:relative md:flex md:items-center md:space-x-8 md:top-0 md:border-none md:shadow-none md:bg-transparent`}
          >
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6 p-4 md:p-0">
              <Link href="/" className="text-primary-600 hover:text-primary-800 font-medium">
                Events
              </Link>
              <Link href="/schedule" className="text-primary-600 hover:text-primary-800 font-medium">
                Schedule
              </Link>
              <Link href="/suggest" className="text-primary-600 hover:text-primary-800 font-medium">
                Suggest a Place
              </Link>
              {user ? (
                <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-4">
                  <div className="flex items-center space-x-2 text-primary-800 font-medium">
                    <User className="h-5 w-5" />
                    <span>{displayName}</span>
                  </div>
                  <Button
                    onClick={signOut}
                    variant="outline"
                    className="w-full md:w-auto border-secondary-300 text-primary-600 hover:text-primary-800 hover:border-secondary-400"
                  >
                    Sign Out
                  </Button>
                </div>
              ) : (
                <Link href="/login">
                  <Button className="w-full md:w-auto bg-primary-500 hover:bg-primary-600 text-white">Log In</Button>
                </Link>
              )}
            </div>
          </nav>
        </div>
      </div>
    </header>
  )
}

