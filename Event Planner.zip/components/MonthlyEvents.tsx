"use client"

import { useEffect } from "react"
import { useEvents } from "@/contexts/EventContext"
import EventList from "./EventList"
import SelectedDayEvents from "./SelectedDayEvents"
import { Calendar } from "@/components/ui/calendar"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getMonthlyEvents } from "@/app/actions"

export default function MonthlyEvents() {
  const { events, setEvents } = useEvents()
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const monthlyEvents = await getMonthlyEvents()
        setEvents(monthlyEvents)
      } catch (error) {
        console.error("Error fetching monthly events:", error)
      }
    }

    fetchEvents()
  }, [setEvents])

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-primary-800">Calendar</CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              className="rounded-md border-secondary-200"
            />
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <SelectedDayEvents events={events} selectedDate={selectedDate} />
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-primary-800">This Month's Events</CardTitle>
        </CardHeader>
        <CardContent>
          <EventList events={events} />
        </CardContent>
      </Card>
    </div>
  )
}

