"use client"

import { createContext, useContext, useEffect, useState } from "react"
import { createClient, type User, AuthError } from "@supabase/supabase-js"
import { useRouter } from "next/navigation"
import toast, { Toaster } from "react-hot-toast"
import { updateUserProfile } from "@/app/actions"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

type AuthContextType = {
  user: User | null
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, fullName: string) => Promise<void>
  signInWithGoogle: () => Promise<void>
  signOut: () => Promise<void>
  updateProfile: (fullName: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const router = useRouter()

  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      const currentUser = session?.user ?? null
      setUser(currentUser)

      if (event === "SIGNED_IN") {
        toast.success("Successfully signed in!")
        router.push("/")
      }
      if (event === "SIGNED_OUT") {
        toast.success("Successfully signed out!")
        router.push("/login")
      }
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [router])

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) throw error
    } catch (error) {
      toast.error("Failed to sign in. Please check your credentials.")
      console.error("Error signing in:", error)
    }
  }

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName },
        },
      })
      if (error) throw error
      toast.success("Registration successful! Please check your email to verify your account.")
    } catch (error) {
      toast.error("Failed to register. Please try again.")
      console.error("Error signing up:", error)
    }
  }

  const signInWithGoogle = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
      })
      if (error) throw error
    } catch (error) {
      toast.error("Failed to sign in with Google. Please try again.")
      console.error("Error signing in with Google:", error)
    }
  }

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) throw error
    } catch (error) {
      toast.error("Failed to sign out. Please try again.")
      console.error("Error signing out:", error)
    }
  }

  const updateProfile = async (fullName: string) => {
    try {
      if (!user) throw new Error("No user logged in")
      await updateUserProfile(user.id, { full_name: fullName })
      toast.success("Profile updated successfully!")
    } catch (error) {
      toast.error("Failed to update profile. Please try again.")
      console.error("Error updating profile:", error)
    }
  }

  return (
    <AuthContext.Provider value={{ user, signIn, signUp, signInWithGoogle, signOut, updateProfile }}>
      {children}
      <Toaster />
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

