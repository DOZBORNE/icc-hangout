import { format } from "date-fns"

type Comment = {
  id: string
  content: string
  created_at: string
  user: {
    id: string
    email: string
    full_name: string
    avatar_url: string
  }
}

export default function CommentList({ comments }: { comments: Comment[] }) {
  return (
    <div className="mt-6 space-y-6" aria-label="Comments section">
      {comments.length === 0 ? (
        <p className="text-primary-600">No comments yet. Be the first to comment!</p>
      ) : (
        <ul className="space-y-6">
          {comments.map((comment) => (
            <li key={comment.id} className="bg-secondary-50 p-4 rounded-lg">
              <article>
                <header className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-primary-700">{comment.user.full_name || comment.user.email}</h3>
                  <time
                    dateTime={comment.created_at}
                    className="text-sm text-primary-500"
                    title={format(new Date(comment.created_at), "MMMM d, yyyy 'at' h:mm a")}
                  >
                    {format(new Date(comment.created_at), "MMM d, yyyy")}
                  </time>
                </header>
                <p className="text-primary-600">{comment.content}</p>
              </article>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

