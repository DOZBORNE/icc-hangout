"use client"

import { useEffect, useState } from "react"
import { getWeeklyEvents } from "@/app/actions"
import EventList from "./EventList"
import type { Event } from "@/types"
import { Calendar } from "@/components/ui/calendar"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

export default function WeeklyEvents() {
  const [events, setEvents] = useState<Event[]>([])
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())

  const fetchEvents = async () => {
    try {
      const fetchedEvents = await getWeeklyEvents()
      setEvents(fetchedEvents)
    } catch (error) {
      console.error("Error fetching weekly events:", error)
    }
  }

  useEffect(() => {
    fetchEvents()

    // Set up real-time listener for events table
    const eventsChannel = supabase
      .channel("events-channel")
      .on("postgres_changes", { event: "*", schema: "public", table: "events" }, () => {
        fetchEvents()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(eventsChannel)
    }
  }, [])

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-lg shadow">
        <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} className="rounded-md border" />
      </div>
      <div>
        <h2 className="text-2xl font-semibold mb-4 text-gray-800">This Week's Events</h2>
        <EventList events={events} />
      </div>
    </div>
  )
}

