"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { suggestPlace } from "@/app/actions"
import { format } from "date-fns"

export default function PlaceSuggestion() {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [date, setDate] = useState<Date | undefined>(undefined)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!date) return
    await suggestPlace({
      title,
      description,
      date: date.toISOString(),
    })
    setTitle("")
    setDescription("")
    setDate(undefined)
  }

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg border border-secondary-200 shadow-sm">
        <Input
          type="text"
          placeholder="Place Name"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="border-secondary-200"
        />
        <Textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
          className="border-secondary-200 min-h-[120px]"
        />
        <div className="bg-secondary-50 p-4 rounded-lg">
          <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border-secondary-200" />
        </div>
        <Button type="submit" className="w-full bg-secondary-500 hover:bg-secondary-600 text-white">
          Suggest Place
        </Button>
      </form>

      {date && (
        <div className="bg-white p-6 rounded-lg border border-secondary-200 shadow-sm">
          <h3 className="text-lg font-semibold text-primary-800 mb-4">Selected Date Preview</h3>
          <p className="text-primary-600">{format(date, "EEEE, MMMM do, yyyy")}</p>
        </div>
      )}
    </div>
  )
}

