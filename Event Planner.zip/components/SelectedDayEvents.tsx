import type { Event } from "@/types"
import { useAuth } from "@/components/AuthProvider"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { format, isValid } from "date-fns"
import { Calendar, Clock, MapPin } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import EventSignUp from "./EventSignUp"

type SelectedDayEventsProps = {
  events: Event[]
  selectedDate: Date | undefined
}

export default function SelectedDayEvents({ events, selectedDate }: SelectedDayEventsProps) {
  const { user } = useAuth()

  if (!selectedDate) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-primary-600">Please select a date to view events.</p>
        </CardContent>
      </Card>
    )
  }

  const filteredEvents = events.filter((event) => new Date(event.date).toDateString() === selectedDate.toDateString())

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-primary-800">
          Events on {format(selectedDate, "MMMM d, yyyy")}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {filteredEvents.length === 0 ? (
          <p className="text-primary-600">No events scheduled for the selected date.</p>
        ) : (
          <ul className="space-y-4">
            {filteredEvents.map((event) => (
              <li key={event.id} className="border-b border-secondary-200 pb-4 last:border-b-0 last:pb-0">
                <div className="space-y-2">
                  <h4 className="font-semibold text-lg text-primary-700">{event.title || "Untitled Event"}</h4>
                  <div className="flex flex-col space-y-1 text-sm text-primary-600">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2" />
                      <span>
                        {isValid(new Date(event.date))
                          ? format(new Date(event.date), "h:mm a")
                          : "Time to be announced"}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span>{event.location || "Location to be announced"}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span>{event.attendees?.length || 0} attendees</span>
                    </div>
                  </div>
                  <p className="text-sm text-primary-600 mt-2">{event.description}</p>
                  <div className="mt-4">
                    {user ? (
                      <EventSignUp eventId={event.id} eventDate={event.date} attendees={event.attendees || []} />
                    ) : (
                      <Link href="/login">
                        <Button className="w-full sm:w-auto bg-primary-500 hover:bg-primary-600 text-white">
                          Sign in to attend
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}

