"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useAuth } from "@/components/AuthProvider"
import { createEvent } from "@/app/actions"
import { toast } from "@/components/ui/use-toast"
import { useEvents } from "@/contexts/EventContext"
import { useLoadScript, Autocomplete } from "@react-google-maps/api"

export default function CreateEventButton() {
  const [isOpen, setIsOpen] = useState(false)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [location, setLocation] = useState("")
  const { user } = useAuth()
  const { refreshEvents } = useEvents()

  const { isLoaded } = useLoadScript({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY!,
    libraries: ["places"],
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (user) {
      try {
        await createEvent({
          title,
          description,
          date: `${date}T${time}`,
          location,
          creator_id: user.id,
        })
        toast({
          title: "Success",
          description: "Event created successfully!",
        })
        setIsOpen(false)
        refreshEvents()
      } catch (error) {
        console.error("Error creating event:", error)
        toast({
          title: "Error",
          description: "Failed to create event. Please try again.",
          variant: "destructive",
        })
      }
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="bg-primary-500 hover:bg-primary-600 text-white">Create Event</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create New Event</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Event Title (e.g., 'Monthly Team Meetup')"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
          <Textarea
            placeholder="Event Description (e.g., 'Join us for our monthly team gathering to discuss projects and socialize')"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} required placeholder="Event Date" />
          <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} required placeholder="Event Time" />
          {isLoaded ? (
            <Autocomplete
              onLoad={(autocomplete) => {
                autocomplete.addListener("place_changed", () => {
                  const place = autocomplete.getPlace()
                  setLocation(place.formatted_address || "")
                })
              }}
            >
              <Input
                placeholder="Event Location (e.g., 'Central Park, New York, NY')"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
              />
            </Autocomplete>
          ) : (
            <Input
              placeholder="Event Location (e.g., 'Central Park, New York, NY')"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              required
            />
          )}
          <Button type="submit" className="w-full bg-primary-500 hover:bg-primary-600 text-white">
            Create Event
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}

