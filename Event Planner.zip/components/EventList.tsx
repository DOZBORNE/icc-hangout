"use client"

import type { Event } from "@/types"
import EventSignUp from "./EventSignUp"
import AttendeesList from "./AttendeesList"
import { useAuth } from "@/components/AuthProvider"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { format, isValid } from "date-fns"
import { Calendar, Clock, MapPin } from "lucide-react"

type EventListProps = {
  events: Event[]
}

export default function EventList({ events }: EventListProps) {
  const { user } = useAuth()

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return isValid(date) ? format(date, "EEEE, MMMM do, yyyy") : "Date to be announced"
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return isValid(date) ? format(date, "h:mm a") : "Time to be announced"
  }

  return (
    <div className="space-y-4">
      {events.length === 0 ? (
        <p className="text-primary-600">No events scheduled for this month.</p>
      ) : (
        <ul className="divide-y divide-secondary-200">
          {events.map((event) => (
            <li key={event.id} className="py-6 first:pt-0 last:pb-0">
              <div className="space-y-4">
                <div>
                  <Link href={`/events/${event.id}`} className="text-lg font-semibold text-primary-800 hover:underline">
                    {event.title || "Untitled Event"}
                  </Link>
                  <p className="mt-1 text-primary-600">{event.description || "No description available"}</p>
                </div>

                <div className="flex flex-col space-y-2">
                  <div className="flex items-center text-primary-600">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{formatDate(event.date)}</span>
                  </div>
                  <div className="flex items-center text-primary-600">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>{formatTime(event.date)}</span>
                  </div>
                  <div className="flex items-center text-primary-600">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{event.location || "Location to be announced"}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-start">
                  <AttendeesList
                    attendees={event.attendees?.map((a) => a.attendee_name) || []}
                    eventName={event.title || "Untitled Event"}
                  />
                  <div className="flex-shrink-0">
                    {user ? (
                      <EventSignUp eventId={event.id} eventDate={event.date} attendees={event.attendees || []} />
                    ) : (
                      <Link href="/login">
                        <Button className="w-full sm:w-auto bg-secondary-500 hover:bg-secondary-600 text-white">
                          Sign in to attend event
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

