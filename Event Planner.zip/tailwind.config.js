/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./pages/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}"],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "#8ea8ab",
          foreground: "#ffffff",
          100: "#f3f6f6",
          200: "#dce5e6",
          300: "#c5d4d6",
          400: "#aec3c5",
          500: "#8ea8ab",
          600: "#718a8d",
          700: "#556769",
          800: "#384446",
          900: "#1c2223",
        },
        secondary: {
          DEFAULT: "#a3c8cc",
          foreground: "#ffffff",
          100: "#f4f8f9",
          200: "#e0ebed",
          300: "#ccdee1",
          400: "#b9d1d4",
          500: "#a3c8cc",
          600: "#82a7ab",
          700: "#628085",
          800: "#415558",
          900: "#212b2c",
        },
        accent: {
          DEFAULT: "#c3e4e8",
          foreground: "#1c2223",
        },
        muted: {
          DEFAULT: "#929494",
          foreground: "#ffffff",
        },
        card: {
          DEFAULT: "#ffffff",
          foreground: "#1c2223",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

