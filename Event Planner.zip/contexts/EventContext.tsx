"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { getMonthlyEvents } from "@/app/actions"
import type { Event } from "@/types"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

interface EventContextType {
  events: Event[]
  setEvents: React.Dispatch<React.SetStateAction<Event[]>>
  updateEvent: (updatedEvent: Event) => void
  refreshEvents: () => Promise<void>
}

const EventContext = createContext<EventContextType | undefined>(undefined)

export function EventProvider({ children }: { children: React.ReactNode }) {
  const [events, setEvents] = useState<Event[]>([])

  const fetchEvents = async () => {
    try {
      const fetchedEvents = await getMonthlyEvents()
      setEvents(fetchedEvents)
    } catch (error) {
      console.error("Error fetching monthly events:", error)
    }
  }

  useEffect(() => {
    fetchEvents()

    const eventsChannel = supabase
      .channel("events-channel")
      .on("postgres_changes", { event: "*", schema: "public", table: "events" }, () => {
        fetchEvents()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(eventsChannel)
    }
  }, [fetchEvents]) // Added fetchEvents to the dependency array

  const updateEvent = (updatedEvent: Event) => {
    setEvents((prevEvents) => prevEvents.map((event) => (event.id === updatedEvent.id ? updatedEvent : event)))
  }

  const refreshEvents = async () => {
    await fetchEvents()
  }

  return (
    <EventContext.Provider value={{ events, setEvents, updateEvent, refreshEvents }}>{children}</EventContext.Provider>
  )
}

export const useEvents = () => {
  const context = useContext(EventContext)
  if (context === undefined) {
    throw new Error("useEvents must be used within an EventProvider")
  }
  return context
}

