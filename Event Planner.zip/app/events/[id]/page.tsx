import { Suspense } from "react"
import { notFound } from "next/navigation"
import Header from "@/components/Header"
import EventDetails from "@/components/EventDetails"
import { getEventById } from "@/app/actions"

export default async function EventPage({ params }: { params: { id: string } }) {
  const event = await getEventById(params.id)

  if (!event) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-secondary-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <Suspense fallback={<div>Loading...</div>}>
          <EventDetails event={event} />
        </Suspense>
      </main>
    </div>
  )
}

