import MonthlyEvents from "@/components/MonthlyEvents"
import UpcomingEvent from "@/components/UpcomingEvent"
import Header from "@/components/Header"
import { EventProvider } from "@/contexts/EventContext"
import CreateEventButton from "@/components/CreateEventButton"

export default function Home() {
  return (
    <EventProvider>
      <div className="min-h-screen bg-secondary-50">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-primary-800">Event Planner</h1>
            <CreateEventButton />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <MonthlyEvents />
            </div>
            <div>
              <UpcomingEvent />
            </div>
          </div>
        </main>
      </div>
    </EventProvider>
  )
}

