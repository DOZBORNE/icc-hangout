import { AuthProvider } from "@/components/AuthProvider"
import { EventProvider } from "@/contexts/EventContext"
import "./globals.css"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-secondary-50">
        <AuthProvider>
          <EventProvider>{children}</EventProvider>
        </AuthProvider>
      </body>
    </html>
  )
}

