import Header from "@/components/Header"
import PlaceSuggestion from "@/components/PlaceSuggestion"

export default function SuggestPage() {
  return (
    <div className="min-h-screen bg-secondary-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-primary-800">Suggest a Place</h1>
        <PlaceSuggestion />
      </main>
    </div>
  )
}

