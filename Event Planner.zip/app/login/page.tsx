"use client"

import { useState } from "react"
import { useAuth } from "@/components/AuthProvider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import Image from "next/image"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [isRegistering, setIsRegistering] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { signIn, signUp, signInWithGoogle } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      if (isRegistering) {
        await signUp(email, password, fullName)
        toast({
          title: "Success",
          description: "Registration successful! Please check your email to verify your account.",
        })
      } else {
        await signIn(email, password)
      }
    } catch (error) {
      console.error("Error signing in:", error)
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary-100 to-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="flex justify-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/icc-hangout-tdbaqOT3VuQXHklM6e6J1TQywHfKfN.svg"
            alt="ICC Hangout"
            width={180}
            height={40}
            className="h-12 w-auto"
          />
        </div>
        <Card className="border-secondary-200">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center text-primary-800">
              {isRegistering ? "Create an Account" : "Welcome Back"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {isRegistering && (
                <Input
                  type="text"
                  placeholder="Full Name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  className="border-secondary-200"
                />
              )}
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="border-secondary-200"
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="border-secondary-200"
              />
              <Button
                type="submit"
                className="w-full bg-secondary-500 hover:bg-secondary-600 text-white"
                disabled={isSubmitting}
              >
                {isRegistering ? (isSubmitting ? "Creating Account..." : "Create Account") : "Sign In"}
              </Button>
            </form>
            <div className="mt-4">
              <Button
                onClick={() => setIsRegistering(!isRegistering)}
                variant="link"
                className="w-full text-primary-600 hover:text-primary-800"
              >
                {isRegistering ? "Already have an account? Sign In" : "Need an account? Create One"}
              </Button>
            </div>
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-secondary-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-primary-500">Or continue with</span>
              </div>
            </div>
            <Button onClick={signInWithGoogle} className="w-full bg-primary-500 hover:bg-primary-600 text-white">
              Sign in with Google
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

