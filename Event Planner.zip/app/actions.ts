"use server"

import { createClient } from "@supabase/supabase-js"
import type { Event } from "@/types"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function getWeeklyEvents(): Promise<Event[]> {
  const startOfWeek = new Date()
  startOfWeek.setHours(0, 0, 0, 0)
  startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay())
  const endOfWeek = new Date(startOfWeek)
  endOfWeek.setDate(endOfWeek.getDate() + 7)

  const { data: events, error } = await supabase
    .from("events")
    .select("*")
    .gte("date", startOfWeek.toISOString())
    .lt("date", endOfWeek.toISOString())
    .order("date", { ascending: true })

  if (error) {
    console.error("Error fetching weekly events:", error)
    throw error
  }

  const eventsWithAttendees = await Promise.all(
    events.map(async (event) => {
      const { data: attendees, error: attendeesError } = await supabase
        .from("event_attendees")
        .select("user_id, attendee_name")
        .eq("event_id", event.id)

      if (attendeesError) {
        console.error("Error fetching attendees for event:", event.id, attendeesError)
        return { ...event, attendees: [] }
      }

      return {
        ...event,
        attendees: attendees || [],
      }
    }),
  )

  return eventsWithAttendees
}

export async function getMonthlyEvents(): Promise<Event[]> {
  const startOfMonth = new Date()
  startOfMonth.setDate(1)
  startOfMonth.setHours(0, 0, 0, 0)
  const endOfMonth = new Date(startOfMonth.getFullYear(), startOfMonth.getMonth() + 1, 0, 23, 59, 59, 999)

  const { data: events, error } = await supabase
    .from("events")
    .select("*")
    .gte("date", startOfMonth.toISOString())
    .lte("date", endOfMonth.toISOString())
    .order("date", { ascending: true })

  if (error) {
    console.error("Error fetching monthly events:", error)
    throw error
  }

  const eventsWithAttendees = await Promise.all(
    events.map(async (event) => {
      const { data: attendees, error: attendeesError } = await supabase
        .from("event_attendees")
        .select("user_id, attendee_name")
        .eq("event_id", event.id)

      if (attendeesError) {
        console.error("Error fetching attendees for event:", event.id, attendeesError)
        return { ...event, attendees: [] }
      }

      return {
        ...event,
        attendees: attendees || [],
      }
    }),
  )

  return eventsWithAttendees
}

export async function getUpcomingEvent(): Promise<Event | null> {
  const { data: events, error } = await supabase
    .from("events")
    .select("*")
    .gt("date", new Date().toISOString())
    .order("date", { ascending: true })
    .limit(1)

  if (error) {
    console.error("Error fetching upcoming event:", error)
    throw error
  }

  return events[0] || null
}

export async function createEvent(eventData: {
  title: string
  description: string
  date: string
  location: string
  creator_id: string
}): Promise<void> {
  const { error } = await supabase.from("events").insert([{ ...eventData }])

  if (error) throw error
}

export async function signUpForEvent(eventId: string, userId: string, name: string): Promise<void> {
  const { error } = await supabase
    .from("event_attendees")
    .insert([{ event_id: eventId, user_id: userId, attendee_name: name }])

  if (error) throw error
}

export async function removeFromEvent(eventId: string, userId: string): Promise<void> {
  const { error } = await supabase.from("event_attendees").delete().match({ event_id: eventId, user_id: userId })

  if (error) throw error
}

export async function suggestPlace(placeData: {
  title: string
  description: string
  date: string
}): Promise<void> {
  const { error } = await supabase.from("places").insert([{ ...placeData }])

  if (error) throw error
}

export async function getEventById(id: string): Promise<Event | null> {
  const { data: event, error } = await supabase.from("events").select("*").eq("id", id).single()

  if (error) {
    console.error("Error fetching event:", error)
    return null
  }

  if (!event) {
    return null
  }

  const { data: attendees, error: attendeesError } = await supabase
    .from("event_attendees")
    .select("user_id, attendee_name")
    .eq("event_id", id)

  if (attendeesError) {
    console.error("Error fetching attendees for event:", id, attendeesError)
    return { ...event, attendees: [] }
  }

  return {
    ...event,
    attendees: attendees || [],
  }
}

export async function uploadEventImage(eventId: string, formData: FormData): Promise<string | null> {
  const file = formData.get("image") as File
  const fileExt = file.name.split(".").pop()
  const fileName = `${eventId}-${Math.random()}.${fileExt}`

  const { data, error } = await supabase.storage.from("event-images").upload(fileName, file)

  if (error) {
    console.error("Error uploading image:", error)
    return null
  }

  const {
    data: { publicUrl },
  } = supabase.storage.from("event-images").getPublicUrl(fileName)

  // Update the event with the new image URL
  const { error: updateError } = await supabase.from("events").update({ image_url: publicUrl }).eq("id", eventId)

  if (updateError) {
    console.error("Error updating event with new image URL:", updateError)
    return null
  }

  return publicUrl
}

export async function addComment(eventId: string, userId: string, content: string): Promise<void> {
  const { error } = await supabase.from("comments").insert({ event_id: eventId, user_id: userId, content })

  if (error) {
    console.error("Error adding comment:", error)
    throw error
  }
}

export async function getComments(eventId: string): Promise<any[]> {
  const { data, error } = await supabase
    .from("comments")
    .select(`
      id,
      content,
      created_at,
      user_id,
      users!inner (
        id,
        email,
        full_name,
        avatar_url
      )
    `)
    .eq("event_id", eventId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching comments:", error)
    throw error
  }

  // Restructure the data to match the expected format
  const commentsWithUserData = data.map((comment) => ({
    id: comment.id,
    content: comment.content,
    created_at: comment.created_at,
    user_id: comment.user_id,
    user: {
      id: comment.users.id,
      email: comment.users.email,
      full_name: comment.users.full_name,
      avatar_url: comment.users.avatar_url,
    },
  }))

  return commentsWithUserData
}

export async function updateUserProfile(
  userId: string,
  userData: {
    full_name?: string
    avatar_url?: string
  },
): Promise<void> {
  const { error } = await supabase.from("users").update(userData).eq("id", userId)

  if (error) {
    console.error("Error updating user profile:", error)
    throw error
  }
}

export async function getUserProfile(userId: string) {
  const { data, error } = await supabase
    .from("users")
    .select("id, email, full_name, avatar_url")
    .eq("id", userId)
    .single()

  if (error) {
    console.error("Error fetching user profile:", error)
    throw error
  }

  return data
}

