export interface Event {
  id: string
  title: string
  description: string
  date: string
  location: string
  creator_id: string
  attendees: Array<{ user_id: string; attendee_name: string }>
}

